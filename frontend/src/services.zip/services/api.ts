// 1. Указываем адрес бэкенда напарника
const BASE_URL = 'http://localhost:5000'; 

// 2. Главная функция-обертка для всех запросов
async function request(endpoint: string, options: RequestInit = {}) {
  // 3. Пытаемся достать токен из хранилища браузера
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;

  // 4. Настраиваем заголовки (Headers)
  const headers: Record<string, string> = {
    'Content-Type': 'application/json', // Говорим серверу, что шлем JSON 
  };

  // 5. Если токен есть, добавляем его для авторизации 
  if (token) {
    headers['Authorization'] = `Bearer ${token}`; 
  }

  // 6. Выполняем сам запрос
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: { ...headers, ...options.headers },
  });

  // 7. Если сервер ответил ошибкой, выкидываем её
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.message || 'Ошибка сервера');
  }

  // 8. Возвращаем данные в формате JSON
  return res.json();
}

// 9. Объект с методами для разных страниц
export const api = {
  auth: {
    // Напарник ждет username и password 
    login: async (data: any) => {
      const response = await request('/auth/login', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      // 10. Сохраняем полученный токен в браузере 
      if (response.token) localStorage.setItem('token', response.token);
      return response;
    },
    // Регистрация нового пользователя [cite: 2, 73]
    register: (data: any) => request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  },
  student: {
    // Получаем список блюд. Напарник подтвердил, что это GET запрос
    getMenu: () => request('/student/menu'),

    // Метод для покупки (нам пригодится кнопка под каждым блюдом)
    buy: (id: number) => request('/student/buy', {
      method: 'POST',
      body: JSON.stringify({ menu_item_id: id, type: 'single' })
    }),
  },
};
