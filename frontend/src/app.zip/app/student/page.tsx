"use client"

import { useEffect, useState } from "react"
import { api } from "@/services/api"
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Star } from "lucide-react"

export default function StudentDashboard() {
  const [menu, setMenu] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [balance, setBalance] = useState(1000) // Баланс из таблицы users
  const [allergies, setAllergies] = useState("")
  const [lastOrderId, setLastOrderId] = useState<number | null>(null)
  const [reviews, setReviews] = useState<{ [key: number]: { rating: number; comment: string } }>({})

  // 1. Загрузка меню (Обязательное требование)
  useEffect(() => {
    async function loadData() {
      try {
        const data = await api.student.getMenu() // GET /student/menu
        setMenu(data)
      } catch (err) {
        console.error("Ошибка загрузки меню. Проверьте эндпоинт /student/menu")
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  // 2. Оплата питания (Разово или Абонемент)
  const handlePurchase = async (itemId: number, type: "single" | "subscription") => {
    try {
      const response = await api.request('/student/buy', {
        method: 'POST',
        body: JSON.stringify({ menu_item_id: itemId, type })
      })
      setLastOrderId(response.orderId)
      setBalance(prev => prev - menu.find(i => i.id === itemId).price)
      alert(`Оплачено как ${type === 'single' ? 'разовый платеж' : 'абонемент'}. Заказ #${response.orderId}`)
    } catch (err) {
      alert("Ошибка оплаты. Проверьте баланс.")
    }
  }

  // 3. Отметка о получении питания (Обязательно для регламента)
  const handleRedeem = async () => {
    if (!lastOrderId) return
    try {
      await api.request(`/student/redeem/${lastOrderId}`, { method: 'POST' })
      alert("Получение подтверждено! Приятного аппетита.")
      setLastOrderId(null)
    } catch (err) {
      alert("Ошибка при получении заказа.")
    }
  }

  // 4. Оставление отзывов (Обязательное требование)
  const submitReview = async (itemId: number) => {
    const review = reviews[itemId]
    if (!review) return
    try {
      // Согласно таблице reviews в README
      await api.request('/student/reviews', {
        method: 'POST',
        body: JSON.stringify({ menu_item_id: itemId, ...review })
      })
      alert("Отзыв отправлен!")
    } catch (err) {
      alert("Не удалось отправить отзыв.")
    }
  }

  if (loading) return <div className="p-10 text-center italic">Загрузка данных...</div>

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Шапка: Баланс и Аллергии */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-white p-6 rounded-xl shadow-sm border">
        <div>
          <h1 className="text-3xl font-bold">Личный кабинет ученика</h1>
          <p className="text-muted-foreground mt-1">Управление школьным питанием</p>
        </div>
        
        <div className="flex gap-6 items-center">
          <div className="text-right">
            <p className="text-xs font-bold text-slate-400 uppercase">Баланс</p>
            <p className="text-2xl font-black text-green-600">{balance} ₽</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs font-bold text-slate-400 uppercase">Мои аллергии</p>
            <Input 
              value={allergies} 
              onChange={(e) => setAllergies(e.target.value)}
              className="w-48 h-9" 
              placeholder="Укажите особенности..." 
            />
          </div>
        </div>
      </div>

      {/* Секция выдачи (Redeem) */}
      {lastOrderId && (
        <Card className="border-2 border-orange-400 bg-orange-50 animate-in fade-in zoom-in">
          <CardContent className="flex flex-col md:flex-row justify-between items-center py-6 gap-4">
            <div className="text-center md:text-left">
              <p className="text-lg font-bold text-orange-800">Заказ #{lastOrderId} готов к выдаче</p>
              <p className="text-orange-700">Покажите это сообщение сотруднику столовой</p>
            </div>
            <Button onClick={handleRedeem} size="lg" className="bg-orange-600 hover:bg-orange-700 text-white font-bold">
              Подтвердить получение
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Основное меню */}
      <Tabs defaultValue="lunch" className="w-full">
        <TabsList className="bg-slate-100 p-1 mb-6">
          <TabsTrigger value="breakfast" className="px-8">Завтраки</TabsTrigger>
          <TabsTrigger value="lunch" className="px-8">Обеды</TabsTrigger>
        </TabsList>

        {["breakfast", "lunch"].map((mealType) => (
          <TabsContent key={mealType} value={mealType} className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {menu.filter(item => item.type === mealType).map((item) => (
              <Card key={item.id} className="flex flex-col overflow-hidden">
                <CardHeader className="bg-slate-50/50">
                  <div className="flex justify-between items-start">
                    <CardTitle>{item.name}</CardTitle>
                    <Badge variant="secondary" className="text-lg">{item.price} ₽</Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-grow pt-4 space-y-4">
                  <p className="text-sm text-muted-foreground h-10 overflow-hidden">{item.description}</p>
                  
                  {/* Мини-форма отзыва */}
                  <div className="bg-slate-50 p-3 rounded-md space-y-2">
                    <p className="text-xs font-bold text-slate-500 uppercase">Ваш отзыв</p>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={star} 
                          size={16} 
                          className={`cursor-pointer ${reviews[item.id]?.rating >= star ? "fill-yellow-400 text-yellow-400" : "text-slate-300"}`}
                          onClick={() => setReviews({ ...reviews, [item.id]: { ...reviews[item.id], rating: star } })}
                        />
                      ))}
                    </div>
                    <Textarea 
                      placeholder="Комментарий..." 
                      className="text-xs min-h-[40px]"
                      onChange={(e) => setReviews({ ...reviews, [item.id]: { ...reviews[item.id], comment: e.target.value } })}
                    />
                    <Button variant="ghost" size="sm" className="w-full h-7 text-xs" onClick={() => submitReview(item.id)}>
                      Отправить отзыв
                    </Button>
                  </div>
                </CardContent>

                <CardFooter className="flex flex-col gap-2 bg-slate-50/30 pt-4">
                  <div className="grid grid-cols-2 gap-2 w-full">
                    <Button 
                      variant="outline" 
                      onClick={() => handlePurchase(item.id, "single")}
                      disabled={item.available_qty <= 0}
                    >
                      Разово
                    </Button>
                    <Button 
                      onClick={() => handlePurchase(item.id, "subscription")}
                      disabled={item.available_qty <= 0}
                    >
                      Абонемент
                    </Button>
                  </div>
                  {item.available_qty <= 5 && (
                    <p className="text-[10px] text-red-500 font-bold">Осталось порций: {item.available_qty}</p>
                  )}
                </CardFooter>
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
