"use client"

import { useState } from "react"
import { api } from "@/services/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CookPage() {
  // Состояние для формы добавления блюда
  const [newItem, setNewItem] = useState({
    name: "",
    description: "",
    price: "",
    type: "lunch",
    available_qty: ""
  })

  // 1. Функция добавления блюда в меню (POST /cook/menu)
  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      // Преобразуем строки в числа, как ждет бэкенд
      await api.request('/cook/menu', {
        method: 'POST',
        body: JSON.stringify({
          ...newItem,
          price: Number(newItem.price),
          available_qty: Number(newItem.available_qty)
        })
      })
      alert("Блюдо добавлено в меню!")
      setNewItem({ name: "", description: "", price: "", type: "lunch", available_qty: "" })
    } catch (err) {
      alert("Ошибка: проверьте права доступа (нужен токен повара)")
    }
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold">Панель управления столовой</h1>

      <Tabs defaultValue="add-menu">
        <TabsList>
          <TabsTrigger value="add-menu">Добавить в меню</TabsTrigger>
          <TabsTrigger value="inventory">Склад и выдача</TabsTrigger>
          <TabsTrigger value="requests">Заявки на закупку</TabsTrigger>
        </TabsList>

        {/* Вкладка 1: Добавление блюд по ТЗ  и README */}
        <TabsContent value="add-menu">
          <Card className="max-w-2xl">
            <CardHeader><CardTitle>Новое блюдо в меню</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={handleAddItem} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input placeholder="Название" value={newItem.name} onChange={e => setNewItem({...newItem, name: e.target.value})} required />
                  <Input type="number" placeholder="Цена (₽)" value={newItem.price} onChange={e => setNewItem({...newItem, price: e.target.value})} required />
                </div>
                <Input placeholder="Описание" value={newItem.description} onChange={e => setNewItem({...newItem, description: e.target.value})} />
                <div className="grid grid-cols-2 gap-4">
                  <select className="flex h-10 w-full rounded-md border border-input bg-background px-3" 
                          value={newItem.type} onChange={e => setNewItem({...newItem, type: e.target.value})}>
                    <option value="lunch">Обед</option>
                    <option value="breakfast">Завтрак</option>
                  </select>
                  <Input type="number" placeholder="Количество порций" value={newItem.available_qty} 
                         onChange={e => setNewItem({...newItem, available_qty: e.target.value})} required />
                </div>
                <Button type="submit" className="w-full">Опубликовать блюдо</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Вкладка 2: Выдача питания  */}
        <TabsContent value="inventory">
          <Card>
            <CardHeader><CardTitle>Очередь на выдачу</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID заказа</TableHead>
                    <TableHead>Блюдо</TableHead>
                    <TableHead className="text-right">Действие</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>#12</TableCell>
                    <TableCell>Борщ Московский</TableCell>
                    <TableCell className="text-right">
                      <Button size="sm">Выдано</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Вкладка 3: Заявки на закупку  */}
        <TabsContent value="requests">
           <Card className="p-6 text-center text-slate-500 border-dashed border-2">
              Здесь повар будет формировать список продуктов для Админа[cite: 35, 40].
           </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
