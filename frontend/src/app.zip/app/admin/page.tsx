"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"

export default function AdminDashboard() {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Панель администратора</h1>
      
      {/* Сводка (Статистика оплат и посещаемости) */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader><CardTitle className="text-sm">Оплачено сегодня</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-bold">12 400 ₽</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-sm">Посещаемость</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-bold">85%</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-sm">Активных абонементов</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-bold">142</p></CardContent>
        </Card>
      </div>

      {/* Согласование заявок */}
      <Card>
        <CardHeader><CardTitle>Заявки на закупку от повара</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Дата</TableHead>
                <TableHead>Продукты</TableHead>
                <TableHead className="text-right">Действие</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>15.01.2026</TableCell>
                <TableCell>Молоко (20л), Яблоки (15кг)</TableCell>
                <TableCell className="text-right space-x-2">
                  <Button variant="outline" size="sm">Отклонить</Button>
                  <Button size="sm">Одобрить</Button>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Button className="w-full" variant="secondary">Сформировать отчет по затратам (.pdf)</Button>
    </div>
  )
}
